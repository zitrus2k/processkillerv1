Hello User!

Thank you for Downloading Process Killer V1!
This Application is still in Development, so it might be buggy.

Made in VS2022 on C#


!WARNING!
1.Do not Kill the Windows Processes like svhost, 
Explorer etc. - this might crash your Computer

2. Some Processes cant be read by this Software, svhost, dllhost etc.

3. If you cant kill Processes run the Application as Administrator


Made by zitrus2k

Zitrus Studios™ 2024